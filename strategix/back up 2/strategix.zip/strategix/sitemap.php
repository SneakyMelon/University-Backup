<?php
	include_once "scripts/head.php";
?>

<body>

<?php
	include_once "scripts/page_nav.php";
?>

	<section id="content" class="not-menu">
	
		<section id="content-body" class="row">

			<?php include_once "scripts/slideshow.php"; ?>
			
				<h1 class="content-header">
					Site Map
				</h1>
			<div class="l">
				<img src="img/sitemap.jpg" alt="Map of the website" style="height: 600px; padding: 10px 0 0 50px;"/>
			</div>
			<?php include_once "scripts/aside.php"; ?>
		</section>
	
	</section>
	
	<?php
		include_once "scripts/footer.php";
	?>
	

</body>