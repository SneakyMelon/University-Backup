<?php
	include_once "scripts/head.php";
?>

<body>
	
	<?php
		include_once "scripts/page_nav.php";
	?>
	
	<section id="content" class="not-menu">
		
		<section id="content-body" class="row">
			
			<?php include_once "scripts/slideshow.php"; ?>
			
			<h1 class="content-header">
				Welcome to the website of StrategiX!
			</h1>
			<div class="l">
				<p>
					The most famous is the dummy text 'Lorem Ipsum', which is said to have originated in the 16th century.
					Lorem Ipsum has been compiled in a pseudo-Latin language more or less in line with 'real' Latin.
					It contains a series of real Latin words. This old dummy text is incomprehensible, but it imitates
					rhythm of most European languages in Latin characters. The advantage of the Latin origin and the relative futility
					of Lorem Ipsum is that the text does not attract attention to themselves or distract the attention of the viewer of the layout.
				</p>
				
				<p>
					A disadvantage of Lorem Ipsum is that in Latin certain letters appear more often than others - and that creates
					a clear visual impression. Moreover, in Latin only words are capitalized at the beginning of sentences; This means that
					Lorem Ipsum is not accurately indicate, for example, German, where all nouns are capitalized. Thus, Lorem Ipsum is simply
					limited suitability as a visual filler for the German texts. When referred to the filling properties of the text that
					different fonts, sometimes it makes sense to select texts containing the various letters and symbols specific to the
					output language.
				</p>
				
				<p>
					There is now a plethora of dummy readable texts. These are usually used when a text must fill pure
					a room. These alternatives to the classic Lorem Ipsum lyrics are often funny and tell short, funny or nonsensical
					stories.
				</p>
			</div>
			<?php include_once "scripts/aside.php"; ?>
		</section>
		
	</section>
	
	<?php
		include_once "scripts/footer.php";
	?>
	
	
</body>