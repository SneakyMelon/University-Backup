<aside class="border r">
	<h2>Get in Contact</h2>
	<h3>Our Address</h3>
	
		<p>
			21 house lane, <br />
			at an adress<br />
			in a city.<br />
			some continent.
		</p>

		<h3>Contact Numbers</h3>
		
		<p>Fax    : +06 (313) 155 99 551</p>
		<p>Tele   : +06 (313) 155 99 555</p>
		<p>Office: +06 (313) 155 99 665</p>
		<p>Email: allan@strategix.com</p>
		
		<p>Or Contact us via our <a class="side-panel-link" href="contact.php">Contact Form</a></p>
		
		<p>
			Find us on Google Maps: <br />
			<a class="side-panel-link" href="http://maps.google.com/?q=strategix-3">Click Here</a>.
		</p>
</aside>