	
	
	<section id="nav-wrapper">
		<header class="row">
			<nav class="row">
				<section class= "nav-row">
					<ul id="page-nav" class="nav-top">
						<li class="nav-top buttonless">
							<a href="tutor.php" class="">Tutor Page</a>
						</li>
						<li class="nav-top buttonless">
							<a href="contact.php" class="">Contact us</a>
						</li>
						<li class="nav-top buttonless">
							<a href="about.php" class="">About Us</a>
						</li>
						<li class="nav-top buttonless block">
							<a class="logo" href="index.php">
								<h1 class="main-logo logo block "><span>S</span>trategi<span>X</span></h1>
							</a>
						</li>
						<li class="nav-top buttonless">
							<a href="topics.php" class="">web topics</a>
						</li>
						<li class="nav-top buttonless">
							<a href="tools.php" class="">Tools</a>
						</li>
						<li class="nav-top buttonless">
							<a href="sitemap.php" class="">sitemap</a>
						</li>
					</ul> 
				</section>
			</nav>
		</header> <!-- END OF header -->
	</section>
	
	<section id="second-nav" class="not-menu">
		<div>
			<div class="center-nav">
				
				<ul><li class="buttonless"><a href="topics.php">Recently Discussed Topics:</a></li>
					<li class="buttonless"><a href="topics.php?topic=1">Databases</a></li>
					<li class="buttonless"><a href="topics.php?topic=2">JavaSripting</a></li>
					<li class="buttonless"><a href="topics.php?topic=3">RIA's</a></li>
					<li class="buttonless"><a href="topics.php?topic=4">Image Manipulation</a></li>
				</ul>
			</div>
		</div>
	</section>
		