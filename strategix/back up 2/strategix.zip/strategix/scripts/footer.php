	
	
	<footer class="">
		<div id="footer-bar"><span> | </span>
			<a href="tools.php" class>Services/ Tools</a><span> | </span>
			<a href="tutor.php" class>Tutor Page</a><span> | </span>
			<a href="topics.php" class>Web Design Blog</a><span> | </span>
			<a href="contact.php" class>Contact Us</a><span> | </span>
			<a href="about.php" class>About Us</a><span> | </span>
			<a href="legal.php" class>Terms and Conditions</a><span> | </span>
		</div>
		<div id="legal">
			<p>
				This webpage is copywright protected &copy; 2014 - StrategiX ltd. 
				
				<br />
				
				Registered company in Scotland Number: SCO-525-2525
			</p>
		</div>
	</footer> <!-- END OF FOOTER -->
	
	<!-- Page scripts with defer options -->
	<script src="js/script.js" defer></script> 