<?php
	include_once "scripts/head.php";
?>

<body>
	
	<?php
		include_once "scripts/page_nav.php";
	?>
	
	<section id="content" class="not-menu">
		
		<section id="content-body" class="row">
			
			<?php include_once "scripts/slideshow.php"; ?>
			
			<h1 class="content-header">
				Welcome to the website of StrategiX!
			</h1>
			<div class="l">
				
				<h2 id="TOS">1.0 Terms of Service</h2>
				<p>
					The most famous is the dummy text 'Lorem Ipsum', which is said to have originated in the 16th century.
					Lorem Ipsum has been compiled in a pseudo-Latin language more or less in line with 'real' Latin.
					It contains a series of real Latin words. This old dummy text is incomprehensible, but it imitates
					rhythm of most European languages in Latin characters. The advantage of the Latin origin and the relative futility
					of Lorem Ipsum is that the text does not attract attention to themselves or distract the attention of the viewer of the layout.
				</p>
				
				<h2>2.0 Security</h2>
				<p>
					There is now a plethora of dummy readable texts. These are usually used when a text must fill pure
					a room. These alternatives to the classic Lorem Ipsum lyrics are often funny and tell short, funny or nonsensical
					stories.
				</p>
				
				<h2>3.0 Collection of Data</h2>
				<p>
					Numquam praesent expetendis sed ea, ut fabellas definitiones pro? Amet dicam appellantur nam te, no per quot 
					fabellas dissentiet. Tritani accusam intellegebat an vel, ex fugit appellantur vituperatoribus cum. Labore omnium 
					lucilius an has, ut has legere alienum, ex est tractatos voluptaria! Utinam honestatis ex vix. Ex ferri nominavi eleifend
					sea! In pro enim homero liberavisse, impetus albucius oportere has ei!
				</p>
				
			</div>
			<?php include_once "scripts/aside.php"; ?>
		</section>
		
	</section>
	
	<?php
		include_once "scripts/footer.php";
	?>
	
	
</body>