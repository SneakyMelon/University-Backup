<?php
	include_once "scripts/head.php";
?>

<body>

<?php
	include_once "scripts/page_nav.php";
?>

	<section id="content" class="not-menu">
	
		<section id="content-body" class="row">

			<?php include_once "scripts/slideshow.php"; ?>
			
				<h1 class="content-header">
					
				</h1>
			<div class="l">
	
			</div>
			<?php include_once "scripts/aside.php"; ?>
		</section>
	
	</section>
	
	<?php
		include_once "scripts/footer.php";
	?>
	

</body>