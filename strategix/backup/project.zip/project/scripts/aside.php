<aside class="border r">
	<h2>Stuur een Onderzoek</h2>
	<h3>Mijn Adres</h3>
	
		<p>
			21 wat gezelschap, <br />
			op een adres<br />
			in een stad.<br />
			sommige continent.
		</p>

		<h3>Nummers</h3>
		
		<p>Fax    : +06 (313) 155 99 551</p>
		<p>Tele   : +06 (313) 155 99 555</p>
		<p>Kantoor: +06 (313) 155 99 665</p>
		<p>Email: allan@strategix.com</p>
		
		<p>Neem contact op via ons <a class="side-panel-link" href="contact.php">contactformulier</a></p>
		
		<p>
			Bezoek ons op Google Maps: <br />
			<a class="side-panel-link" href="http://maps.google.com/?q=strategix-3">klik hier</a>.
		</p>
</aside>