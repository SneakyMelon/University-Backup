	
	
	<footer class="">
		<div id="footer-bar"><span> | </span>
			<a href="#" class>Services</a><span> | </span>
			<a href="#" class>Portfolio</a><span> | </span>
			<a href="#" class>Blog</a><span> | </span>
			<a href="#" class>Contact Us</a><span> | </span>
			<a href="#" class>About Us</a><span> | </span>
			<a href="#" class>Terms and Conditions</a><span> | </span>
		</div>
		<div id="legal">
			<p>
				This webpage is copywright protected &copy; 2014 - StrategiX ltd. 
				
				<br />
				
				Registered company in Scotland Number: SCO-525-2525
			</p>
		</div>
	</footer> <!-- END OF FOOTER -->
	
	<!-- Page scripts with defer options -->
	<script src="js\script.js" defer></script> 
	
	<!-- <script src="" defer=""></script> -->
	