
	<div id="slideshow">
		<img class="slide" src="img\banner_one.jpg" />
	</div>
