
<!DOCTYPE html>

<!---
	Assesors page:
		have a checklist that tix all the boxesa, lololol #stolen #yolo #rooree #who?

--->
<head>
	
	<title>Strateg:IX Web Design</title>
	
	<!-- CSS -->
		<link rel="stylesheet" href="css\main.style.reset.css">
		<link rel="stylesheet" href="css\main.style.css">
		<!-- Fonts -->
		<link href='http://fonts.googleapis.com/css?family=Fjord+One' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Cinzel' rel='stylesheet' type='text/css'>
	<!-- END OF CSS -->
</head>
